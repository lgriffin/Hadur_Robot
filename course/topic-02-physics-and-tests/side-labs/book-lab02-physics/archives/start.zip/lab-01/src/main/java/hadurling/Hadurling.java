package hadurling;

import robocode.AdvancedRobot;
import robocode.HitWallEvent;
import robocode.ScannedRobotEvent;
import robocode.util.Utils;

/**
 * Hadurling, lab 01: a robot that finds its enemy, keeps its radar on it, circles it and
 * shoots at it.
 *
 * <p>Every tick the engine lets the robot decide, then moves the world on one step. The
 * robot's decisions are <em>orders</em> ({@code setTurnRight}, {@code setFire} and so on):
 * they only take effect when {@code execute()} ends the tick. The enemy's position is only
 * learned when the radar sees it, and then the engine calls
 * {@link #onScannedRobot(ScannedRobotEvent)}.</p>
 *
 * <p>All angles in this class are in radians, in Robocode's convention: 0 is north,
 * and angles grow clockwise.</p>
 */
public class Hadurling extends AdvancedRobot {

    /**
     * How many rounds this battle has started. {@code static}, so it belongs to the class, not
     * to one robot object: Robocode builds a <em>new</em> {@code Hadurling} object for every
     * round, and a normal field would start again at zero each time.
     */
    private static int roundsStarted;

    /** How far to drive on each tick, in pixels. A new order each tick keeps the robot moving. */
    private static final double STEP = 100;

    /** The bullet power Hadurling always fires. Power 1 is cheap and fast enough to learn from. */
    private static final double FIRE_POWER = 1.0;

    /** 1 drives forwards, -1 backwards. Flips when the robot hits a wall. */
    private int direction = 1;

    /** The tick on which the radar last saw the enemy; used to notice we have lost it. */
    private long lastScanTime = -100;

    /** The engine calls this once per round. It is the robot's main loop. */
    @Override
    public void run() {
        roundsStarted++;
        out.println("Round " + roundsStarted + " of this battle");

        // Let the gun and the radar turn independently of the body, so turning to circle
        // the enemy does not drag the aim away from it.
        setAdjustGunForRobotTurn(true);
        setAdjustRadarForGunTurn(true);

        while (true) {
            // If we have not seen the enemy for a couple of ticks, sweep until we do.
            if (getTime() - lastScanTime > 2) {
                setTurnRadarRightRadians(Double.POSITIVE_INFINITY);
            }
            execute();
        }
    }

    /**
     * The radar saw the enemy. Lock the radar on it, circle it, and shoot.
     *
     * @param e what the radar saw: the enemy's bearing from our heading, its distance and so on
     */
    @Override
    public void onScannedRobot(ScannedRobotEvent e) {
        lastScanTime = getTime();

        // Where the enemy is, as a compass direction rather than relative to our heading.
        double enemyDirection = getHeadingRadians() + e.getBearingRadians();

        // Radar lock: turn the radar to the enemy, and twice as far, so it overshoots and
        // sweeps back across it. The radar then sees the enemy again next tick.
        double radarTurn = Utils.normalRelativeAngle(enemyDirection - getRadarHeadingRadians());
        setTurnRadarRightRadians(2 * radarTurn);

        // Orbit: point the body at a right angle to the enemy and keep driving. The bearing
        // is 0 when the enemy is dead ahead, so adding 90 degrees turns us side-on to it.
        setTurnRightRadians(Utils.normalRelativeAngle(e.getBearingRadians() + Math.PI / 2));
        setAhead(STEP * direction);

        // Aim the gun straight at the enemy, and fire once the gun has cooled down. The
        // engine will not fire a hot gun anyway, but checking keeps our intent clear.
        double gunTurn = Utils.normalRelativeAngle(enemyDirection - getGunHeadingRadians());
        setTurnGunRightRadians(gunTurn);
        if (getGunHeat() == 0 && Math.abs(gunTurn) < Math.toRadians(10)) {
            setFire(FIRE_POWER);
        }
    }

    /**
     * We drove into a wall: turn around so the orbit takes us back into the field.
     *
     * @param e the engine's report of the collision
     */
    @Override
    public void onHitWall(HitWallEvent e) {
        direction = -direction;
    }
}
