package hadurling;

import hadurling.model.Event;
import hadurling.model.Input;
import hadurling.model.Orders;
import java.util.ArrayList;
import java.util.List;
import robocode.AdvancedRobot;
import robocode.BulletHitEvent;
import robocode.HitByBulletEvent;
import robocode.HitWallEvent;
import robocode.RobotDeathEvent;
import robocode.ScannedRobotEvent;

/**
 * Hadurling, lab 03: the Robocode adapter. It only translates. Engine events become
 * {@link Event} values and the getters become an {@link Input}; the {@link Brain} turns that
 * into {@link Orders}; and this class turns the orders into engine calls.
 *
 * <p>One tick: the engine delivers events during {@code execute()}, our handlers queue them
 * in {@code pending}; the loop then builds an {@code Input}, asks the brain, applies the
 * orders and calls {@code execute()} again.</p>
 */
public class Hadurling extends AdvancedRobot {

    /** Rounds started this battle; static so it survives the new robot object each round. */
    private static int roundsStarted;

    /** Events delivered since the last tick, in delivery order. */
    private final List<Event> pending = new ArrayList<>();

    /** The brain for this round. */
    private final Brain brain = new Brain();

    /** The main loop: one brain decision per tick. */
    @Override
    public void run() {
        roundsStarted++;
        out.println("Round " + roundsStarted + " of this battle");
        setAdjustGunForRobotTurn(true);
        setAdjustRadarForGunTurn(true);

        while (true) {
            Input in = input();
            apply(brain.think(in));
            execute();
        }
    }

    /** This tick's input: the getters plus the queued events, which are then cleared. */
    private Input input() {
        Input in = new Input(getTime(), getX(), getY(), getHeadingRadians(), getVelocity(),
            getEnergy(), getGunHeat(), getGunHeadingRadians(), getRadarHeadingRadians(), pending);
        pending.clear();
        return in;
    }

    /** Turns orders into setter calls. NaN means "do not call the setter". */
    private void apply(Orders o) {
        if (!Double.isNaN(o.bodyTurn())) setTurnRightRadians(o.bodyTurn());
        if (!Double.isNaN(o.ahead())) setAhead(o.ahead());
        if (!Double.isNaN(o.gunTurn())) setTurnGunRightRadians(o.gunTurn());
        if (!Double.isNaN(o.radarTurn())) setTurnRadarRightRadians(o.radarTurn());
        if (o.firePower() > 0) setFire(o.firePower());
    }

    /**
     * The radar saw a robot.
     *
     * @param e the engine's scan report
     */
    @Override
    public void onScannedRobot(ScannedRobotEvent e) {
        pending.add(new Event.Scan(e.getName(), e.getBearingRadians(), e.getDistance(),
            e.getEnergy(), e.getHeadingRadians(), e.getVelocity()));
    }

    /**
     * An enemy bullet hit us.
     *
     * @param e the engine's report
     */
    @Override
    public void onHitByBullet(HitByBulletEvent e) {
        pending.add(new Event.HitByBullet(e.getName(), e.getPower()));
    }

    /**
     * One of our bullets hit a robot.
     *
     * @param e the engine's report
     */
    @Override
    public void onBulletHit(BulletHitEvent e) {
        pending.add(new Event.BulletHit(e.getName(), e.getBullet().getPower()));
    }

    /**
     * We drove into a wall.
     *
     * @param e the engine's report
     */
    @Override
    public void onHitWall(HitWallEvent e) {
        pending.add(new Event.HitWall(e.getBearingRadians()));
    }

    /**
     * Another robot died.
     *
     * @param e the engine's report
     */
    @Override
    public void onRobotDeath(RobotDeathEvent e) {
        pending.add(new Event.RobotDeath(e.getName()));
    }
}
